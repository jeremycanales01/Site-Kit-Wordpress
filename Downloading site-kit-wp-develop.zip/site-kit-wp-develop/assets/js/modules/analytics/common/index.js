/**
 * Analytics common components.
 *
 * Site Kit by Google, Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

export { default as AccountCreateLegacy } from './account-create-legacy';
export { default as AccountCreate } from './account-create';
export { default as AccountSelect } from './account-select';
export { default as AnonymizeIPSwitch } from './anonymize-ip-switch';
export { default as ErrorNotice } from './error-notice';
export { default as ExistingTagError } from './existing-tag-error';
export { default as ExistingTagNotice } from './existing-tag-notice';
export { default as ProfileNameTextField } from './ProfileNameTextField';
export { default as ProfileSelect } from './profile-select';
export { default as PropertySelect } from './property-select';
export { default as TrackingExclusionSwitches } from './tracking-exclusion-switches';
export { default as UseSnippetSwitch } from './use-snippet-switch';
