export { default as getNotifications } from './get-notifications';
export {
	markNotification,
	acceptNotification,
	dismissNotification,
} from './mark-notification';
