# Contributing and Maintaining

Any kind of contributions to Site Kit by Google are welcome. Head over to the [Contributor Handhook](https://github.com/google/site-kit-wp/wiki) to get started, or directly to the [Engineering set up quickstart](https://github.com/google/site-kit-wp/wiki/Engineering#set-up-site-kit-project) to set up Sit Kit locally. :wink:
